# =============================================================================
# Trend-Based Clustering of Regional Development — Validation Dashboard
# Companion Shiny app for:
# "A Validation Framework for Trend-Based Clustering of Regional Development:
#  Multi-Algorithm Agreement and Bootstrap Stability"
#
# Implements: OLS trend-slope extraction, z-standardization, k-selection
# (Silhouette / Davies-Bouldin / Calinski-Harabasz / Gap statistic),
# 7-algorithm comparison (PAM, CLARA, K-Means, Ward.D2, Complete, Average, GMM),
# inter-algorithm agreement (Adjusted Rand Index), bootstrap Jaccard stability,
# bootstrap Silhouette CI, cluster profiling/PCA, and a Theil-Sen sensitivity check.
# =============================================================================

required_pkgs <- c("shiny", "DT", "cluster", "fpc", "mclust",
                    "ggplot2", "reshape2")
new_pkgs <- setdiff(required_pkgs, rownames(installed.packages()))
if (length(new_pkgs) > 0) {
  install.packages(new_pkgs, repos = "https://cloud.r-project.org")
}
invisible(lapply(required_pkgs, library, character.only = TRUE))

set.seed(123)

# ----------------------------------------------------------------------------
# Helper functions
# ----------------------------------------------------------------------------

ols_slope <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  if (sum(ok) < 2) return(NA_real_)
  unname(coef(lm(y[ok] ~ x[ok]))[2])
}

theilsen_slope <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  x <- x[ok]; y <- y[ok]
  n <- length(x)
  if (n < 2) return(NA_real_)
  pairs <- combn(n, 2)
  slopes <- apply(pairs, 2, function(idx) {
    dx <- x[idx[2]] - x[idx[1]]
    if (dx == 0) return(NA_real_)
    (y[idx[2]] - y[idx[1]]) / dx
  })
  median(slopes, na.rm = TRUE)
}

compute_slope_matrix <- function(df, region_col, year_col, indicators,
                                  log_map, method = c("ols", "theilsen")) {
  method <- match.arg(method)
  regions <- unique(df[[region_col]])
  B <- matrix(NA_real_, nrow = length(regions), ncol = length(indicators),
              dimnames = list(regions, indicators))
  for (r in regions) {
    sub <- df[df[[region_col]] == r, , drop = FALSE]
    x <- sub[[year_col]]
    for (ind in indicators) {
      y <- sub[[ind]]
      if (isTRUE(log_map[[ind]])) y <- suppressWarnings(log(y))
      B[r, ind] <- if (method == "ols") ols_slope(x, y) else theilsen_slope(x, y)
    }
  }
  B
}

standardize <- function(B) scale(B)

# Davies-Bouldin index, implemented manually (no external dependency beyond base R)
db_index <- function(Z, cl) {
  tryCatch({
    clusters <- sort(unique(cl))
    k <- length(clusters)
    if (k < 2) return(NA_real_)
    centroids <- t(sapply(clusters, function(cc) colMeans(Z[cl == cc, , drop = FALSE])))
    s <- sapply(seq_along(clusters), function(i) {
      pts <- Z[cl == clusters[i], , drop = FALSE]
      ctr <- centroids[i, ]
      mean(sqrt(rowSums(sweep(pts, 2, ctr, "-")^2)))
    })
    R <- matrix(0, k, k)
    for (i in 1:k) for (j in 1:k) if (i != j) {
      d_ij <- sqrt(sum((centroids[i, ] - centroids[j, ])^2))
      R[i, j] <- if (d_ij > 0) (s[i] + s[j]) / d_ij else NA_real_
    }
    mean(apply(R, 1, max, na.rm = TRUE))
  }, error = function(e) NA_real_)
}

# Calinski-Harabasz index via fpc::cluster.stats
ch_index <- function(Z, cl) {
  tryCatch(fpc::cluster.stats(dist(Z), cl)$ch, error = function(e) NA_real_)
}
sil_index <- function(Z, cl) {
  if (length(unique(cl)) < 2) return(NA_real_)
  mean(cluster::silhouette(cl, dist(Z))[, 3])
}

run_algorithms <- function(Z, k) {
  d <- dist(Z)
  res <- list()
  res$PAM      <- cluster::pam(Z, k)$clustering
  res$CLARA    <- cluster::clara(Z, k)$clustering
  res$KMeans   <- kmeans(Z, centers = k, nstart = 50)$cluster
  res$Ward     <- cutree(hclust(d, method = "ward.D2"), k)
  res$Complete <- cutree(hclust(d, method = "complete"), k)
  res$Average  <- cutree(hclust(d, method = "average"), k)
  gmm <- tryCatch(mclust::Mclust(Z, G = k, verbose = FALSE), error = function(e) NULL)
  res$GMM <- if (!is.null(gmm)) gmm$classification else rep(NA_integer_, nrow(Z))
  res
}

k_selection_curve <- function(Z, k_range = 2:8) {
  d <- dist(Z)
  out <- data.frame()
  for (k in k_range) {
    pam_cl  <- cluster::pam(Z, k)$clustering
    ward_cl <- cutree(hclust(d, method = "ward.D2"), k)
    out <- rbind(out,
      data.frame(k = k, method = "PAM",
                 Silhouette = sil_index(Z, pam_cl),
                 DaviesBouldin = db_index(Z, pam_cl),
                 CalinskiHarabasz = ch_index(Z, pam_cl)),
      data.frame(k = k, method = "Ward.D2",
                 Silhouette = sil_index(Z, ward_cl),
                 DaviesBouldin = db_index(Z, ward_cl),
                 CalinskiHarabasz = ch_index(Z, ward_cl))
    )
  }
  out
}

# ----------------------------------------------------------------------------
# Default bundled dataset (35 districts/cities, Central Java, 2020-2024)
# ----------------------------------------------------------------------------
default_path <- file.path("data", "panel_data.csv")
default_df <- if (file.exists(default_path)) read.csv(default_path, stringsAsFactors = FALSE) else NULL

default_indicator_cols <- c("PDRB", "Kemiskinan", "Sanitasi", "KontribusiIndustri",
                             "PertumbuhanIndustri", "JumlahIndustri", "TPAK", "TPT", "IPM")
default_direction <- c(PDRB = 1, Kemiskinan = -1, Sanitasi = 1, KontribusiIndustri = 1,
                        PertumbuhanIndustri = 1, JumlahIndustri = 1, TPAK = 1, TPT = -1, IPM = 1)
default_log <- c(PDRB = TRUE, Kemiskinan = FALSE, Sanitasi = FALSE, KontribusiIndustri = FALSE,
                  PertumbuhanIndustri = FALSE, JumlahIndustri = TRUE, TPAK = FALSE,
                  TPT = FALSE, IPM = FALSE)
indicator_labels <- c(PDRB = "PDRB (growth, log)", Kemiskinan = "Tingkat Kemiskinan",
                       Sanitasi = "Akses Sanitasi Layak", KontribusiIndustri = "Kontribusi Sektor Industri",
                       PertumbuhanIndustri = "Pertumbuhan Industri", JumlahIndustri = "Jumlah Usaha Industri (log)",
                       TPAK = "Tingkat Partisipasi Angkatan Kerja", TPT = "Tingkat Pengangguran Terbuka",
                       IPM = "Indeks Pembangunan Manusia")

# =============================================================================
# UI
# =============================================================================
ui <- navbarPage(
  title = "Trend-Based Clustering Dashboard \u2014 Jawa Tengah",
  theme = NULL,

  tabPanel("1. Data & Setup",
    sidebarLayout(
      sidebarPanel(width = 4,
        h4("Sumber Data"),
        fileInput("upload", "Upload panel data (.csv)", accept = ".csv"),
        helpText("Kosongkan untuk memakai data bawaan (35 kab/kota Jawa Tengah, 2020\u20132024)."),
        hr(),
        uiOutput("column_mapping_ui"),
        hr(),
        uiOutput("indicator_config_ui"),
        hr(),
        numericInput("k_choice", "Jumlah cluster (k) untuk analisis utama:", value = 2, min = 2, max = 8, step = 1),
        numericInput("boot_B", "Jumlah replikasi bootstrap (B):", value = 500, min = 50, max = 2000, step = 50),
        actionButton("run", "Jalankan Analisis", class = "btn-primary", width = "100%")
      ),
      mainPanel(width = 8,
        h4("Pratinjau Data Panel"),
        DTOutput("raw_table"),
        br(),
        verbatimTextOutput("data_summary")
      )
    )
  ),

  tabPanel("2. Ekstraksi Tren",
    fluidRow(
      column(12,
        h4("Matriks Slope (\u03b2) per Wilayah \u00d7 Indikator (OLS, 2020\u20132024)"),
        p("Slope diestimasi dari regresi OLS indikator terhadap tahun untuk setiap wilayah; ",
          "PDRB dan Jumlah Usaha Industri di log-transform sebelum estimasi slope."),
        DTOutput("slope_table"),
        br(),
        h4("Matriks Terstandardisasi (Z-score)"),
        DTOutput("z_table")
      )
    )
  ),

  tabPanel("3. Pemilihan k",
    fluidRow(
      column(6, plotOutput("plot_sil_k")),
      column(6, plotOutput("plot_db_k"))
    ),
    fluidRow(
      column(6, plotOutput("plot_ch_k")),
      column(6, plotOutput("plot_gap_k"))
    ),
    hr(),
    h4("Ringkasan Kriteria Pemilihan k"),
    DTOutput("k_summary_table")
  ),

  tabPanel("4. Perbandingan Algoritma",
    h4(textOutput("algo_header")),
    DTOutput("algo_table"),
    br(),
    plotOutput("cluster_size_plot")
  ),

  tabPanel("5. Kesepakatan Antar-Algoritma (ARI)",
    h4("Adjusted Rand Index antar Pasangan Algoritma"),
    plotOutput("ari_heatmap", height = "500px"),
    br(),
    DTOutput("ari_table")
  ),

  tabPanel("6. Stabilitas Bootstrap",
    h4("Jaccard Bootstrap Stability per Cluster (PAM, Ward, K-Means)"),
    p("Garis putus-putus menandai ambang stabilitas 0.75 (Hennig, 2007)."),
    plotOutput("jaccard_plot", height = "450px"),
    DTOutput("jaccard_table"),
    hr(),
    h4("Bootstrap CI untuk Rata-rata Silhouette (solusi PAM terpilih)"),
    verbatimTextOutput("sil_ci_text"),
    plotOutput("sil_boot_hist")
  ),

  tabPanel("7. Tipologi & Profil Cluster",
    fluidRow(
      column(6,
        h4("Proyeksi PCA (PC1 vs PC2)"),
        plotOutput("pca_plot", height = "450px")
      ),
      column(6,
        h4("Profil Cluster (rata-rata slope terstandardisasi)"),
        plotOutput("profile_plot", height = "450px")
      )
    ),
    hr(),
    h4("Rata-rata Slope Mentah per Cluster"),
    DTOutput("profile_table"),
    hr(),
    fluidRow(
      column(6, h4("Anggota Cluster 1"), verbatimTextOutput("cluster1_members")),
      column(6, h4("Anggota Cluster 2+"), verbatimTextOutput("cluster2_members"))
    )
  ),

  tabPanel("8. Sensitivitas (Theil-Sen)",
    p("Slope OLS digantikan estimator Theil-Sen (median dari seluruh slope pasangan titik), ",
      "kemudian clustering PAM dijalankan ulang pada k yang sama. ",
      "Adjusted Rand Index membandingkan partisi hasil kedua estimator."),
    verbatimTextOutput("sensitivity_text"),
    DTOutput("sensitivity_table")
  )
)

# =============================================================================
# SERVER
# =============================================================================
server <- function(input, output, session) {

  # ---------------- Data source ----------------
  raw_data <- reactive({
    if (!is.null(input$upload)) {
      df <- read.csv(input$upload$datapath, stringsAsFactors = FALSE)
    } else {
      df <- default_df
    }
    validate(need(!is.null(df), "Tidak ada data. Upload file CSV atau pastikan data bawaan tersedia."))
    df
  })

  output$raw_table <- renderDT({
    datatable(raw_data(), options = list(pageLength = 8, scrollX = TRUE))
  })

  output$data_summary <- renderPrint({
    df <- raw_data()
    cat("Jumlah baris:", nrow(df), "\n")
    cat("Kolom:", paste(colnames(df), collapse = ", "), "\n")
    if (!is.null(input$region_col) && input$region_col %in% colnames(df)) {
      cat("Jumlah wilayah unik:", length(unique(df[[input$region_col]])), "\n")
    }
    na_counts <- colSums(is.na(df))
    if (any(na_counts > 0)) {
      cat("\nNilai kosong (NA) per kolom:\n")
      print(na_counts[na_counts > 0])
    } else {
      cat("\nTidak ada nilai kosong.\n")
    }
  })

  # ---------------- Column mapping UI ----------------
  output$column_mapping_ui <- renderUI({
    df <- raw_data()
    cols <- colnames(df)
    region_guess <- if ("Kabupaten_Kota" %in% cols) "Kabupaten_Kota" else cols[1]
    year_guess   <- if ("Tahun" %in% cols) "Tahun" else cols[2]
    tagList(
      h4("Pemetaan Kolom"),
      selectInput("region_col", "Kolom Wilayah:", choices = cols, selected = region_guess),
      selectInput("year_col", "Kolom Tahun:", choices = cols, selected = year_guess)
    )
  })

  numeric_candidates <- reactive({
    df <- raw_data()
    req(input$region_col, input$year_col)
    cols <- setdiff(colnames(df), c(input$region_col, input$year_col))
    cols[sapply(df[cols], is.numeric)]
  })

  output$indicator_config_ui <- renderUI({
    cands <- numeric_candidates()
    req(length(cands) > 0)
    preselect <- intersect(default_indicator_cols, cands)
    if (length(preselect) == 0) preselect <- cands
    tagList(
      h4("Pilih Indikator"),
      checkboxGroupInput("indicator_cols", NULL, choices = cands, selected = preselect),
      helpText("Untuk setiap indikator terpilih, atur arah kebijakan dan log-transform di bawah."),
      uiOutput("indicator_direction_ui")
    )
  })

  output$indicator_direction_ui <- renderUI({
    req(input$indicator_cols)
    rows <- lapply(input$indicator_cols, function(ind) {
      dir_default <- if (ind %in% names(default_direction)) default_direction[[ind]] else 1
      log_default <- if (ind %in% names(default_log)) default_log[[ind]] else FALSE
      fluidRow(
        column(6, tags$b(ind)),
        column(3, selectInput(paste0("dir_", ind), NULL,
                               choices = c("Desirable (+1)" = "1", "Undesirable (-1)" = "-1"),
                               selected = as.character(dir_default))),
        column(3, checkboxInput(paste0("log_", ind), "log-transform", value = log_default))
      )
    })
    do.call(tagList, rows)
  })

  indicator_config <- reactive({
    req(input$indicator_cols)
    inds <- input$indicator_cols
    direction <- setNames(sapply(inds, function(ind) as.numeric(input[[paste0("dir_", ind)]])), inds)
    log_map <- setNames(sapply(inds, function(ind) isTRUE(input[[paste0("log_", ind)]])), inds)
    list(indicators = inds, direction = direction, log_map = log_map)
  })

  # ---------------- Main analysis pipeline (on button press) ----------------
  results <- eventReactive(input$run, {
    df <- raw_data()
    cfg <- indicator_config()
    region_col <- input$region_col
    year_col <- input$year_col
    inds <- cfg$indicators
    k <- input$k_choice
    B_boot <- input$boot_B

    withProgress(message = "Menjalankan analisis...", value = 0, {

      incProgress(0.1, detail = "Ekstraksi slope (OLS)")
      B <- compute_slope_matrix(df, region_col, year_col, inds, cfg$log_map, method = "ols")
      Z <- standardize(B)

      incProgress(0.15, detail = "Pemilihan k")
      k_curve <- k_selection_curve(Z, 2:8)
      gap <- tryCatch(
        cluster::clusGap(Z, FUNcluster = function(x, k) list(cluster = cluster::pam(x, k)$clustering),
                          K.max = 8, B = 50),
        error = function(e) NULL
      )

      incProgress(0.2, detail = "Menjalankan 7 algoritma")
      algos <- run_algorithms(Z, k)
      algo_metrics <- do.call(rbind, lapply(names(algos), function(nm) {
        cl <- algos[[nm]]
        sizes <- table(cl)
        data.frame(Algorithm = nm,
                   Silhouette = round(sil_index(Z, cl), 3),
                   DaviesBouldin = round(db_index(Z, cl), 3),
                   ClusterSizes = paste(sizes, collapse = " vs "),
                   MinClusterSize = min(sizes))
      }))

      incProgress(0.15, detail = "Menghitung ARI antar algoritma")
      algo_names <- names(algos)
      ari_mat <- matrix(NA_real_, length(algo_names), length(algo_names),
                         dimnames = list(algo_names, algo_names))
      for (i in seq_along(algo_names)) {
        for (j in seq_along(algo_names)) {
          ari_mat[i, j] <- mclust::adjustedRandIndex(algos[[algo_names[i]]], algos[[algo_names[j]]])
        }
      }

      incProgress(0.2, detail = "Bootstrap stability (Jaccard)")
      cb_pam  <- fpc::clusterboot(Z, B = B_boot, clustermethod = fpc::pamkCBI,
                                   k = k, seed = 123, count = FALSE)
      cb_ward <- fpc::clusterboot(Z, B = B_boot, clustermethod = fpc::hclustCBI,
                                   k = k, method = "ward.D2", seed = 123, count = FALSE)
      cb_km   <- fpc::clusterboot(Z, B = B_boot, clustermethod = fpc::kmeansCBI,
                                   k = k, seed = 123, count = FALSE)
      jaccard_df <- data.frame(
        Cluster = rep(1:k, 3),
        Algorithm = rep(c("PAM", "Ward.D2", "K-Means"), each = k),
        Jaccard = c(cb_pam$bootmean, cb_ward$bootmean, cb_km$bootmean)
      )

      incProgress(0.1, detail = "Bootstrap Silhouette CI")
      sil_boot <- numeric(min(B_boot, 500))
      n_obs <- nrow(Z)
      for (b in seq_along(sil_boot)) {
        idx <- sample(seq_len(n_obs), replace = TRUE)
        Zb <- Z[idx, , drop = FALSE]
        pam_b <- tryCatch(cluster::pam(Zb, k), error = function(e) NULL)
        sil_boot[b] <- if (!is.null(pam_b)) sil_index(Zb, pam_b$clustering) else NA_real_
      }
      sil_ci <- quantile(sil_boot, c(0.025, 0.975), na.rm = TRUE)

      incProgress(0.05, detail = "Sensitivitas Theil-Sen")
      B_ts <- compute_slope_matrix(df, region_col, year_col, inds, cfg$log_map, method = "theilsen")
      Z_ts <- standardize(B_ts)
      pam_ts <- cluster::pam(Z_ts, k)$clustering
      ari_sensitivity <- mclust::adjustedRandIndex(algos$PAM, pam_ts)

      incProgress(0.05, detail = "Selesai")

      list(
        B = B, Z = Z, k = k, k_curve = k_curve, gap = gap,
        algos = algos, algo_metrics = algo_metrics, ari_mat = ari_mat,
        jaccard_df = jaccard_df, sil_boot = sil_boot, sil_ci = sil_ci,
        B_ts = B_ts, pam_ts = pam_ts, ari_sensitivity = ari_sensitivity,
        direction = cfg$direction, region_col = region_col
      )
    })
  })

  # ---------------- Tab 2: trend extraction ----------------
  output$slope_table <- renderDT({
    req(results())
    datatable(round(results()$B, 4), options = list(pageLength = 10, scrollX = TRUE))
  })
  output$z_table <- renderDT({
    req(results())
    datatable(round(results()$Z, 3), options = list(pageLength = 10, scrollX = TRUE))
  })

  # ---------------- Tab 3: k selection ----------------
  output$plot_sil_k <- renderPlot({
    req(results())
    kc <- results()$k_curve
    ggplot(kc, aes(k, Silhouette, color = method)) + geom_line() + geom_point() +
      labs(title = "Silhouette vs k (lebih tinggi lebih baik)", x = "k", y = "Silhouette") +
      theme_minimal()
  })
  output$plot_db_k <- renderPlot({
    req(results())
    kc <- results()$k_curve
    ggplot(kc, aes(k, DaviesBouldin, color = method)) + geom_line() + geom_point() +
      labs(title = "Davies-Bouldin vs k (lebih rendah lebih baik)", x = "k", y = "Davies-Bouldin") +
      theme_minimal()
  })
  output$plot_ch_k <- renderPlot({
    req(results())
    kc <- results()$k_curve
    ggplot(kc, aes(k, CalinskiHarabasz, color = method)) + geom_line() + geom_point() +
      labs(title = "Calinski-Harabasz vs k (lebih tinggi lebih baik)", x = "k", y = "Calinski-Harabasz") +
      theme_minimal()
  })
  output$plot_gap_k <- renderPlot({
    req(results())
    gap <- results()$gap
    if (is.null(gap)) {
      plot.new(); text(0.5, 0.5, "Gap statistic tidak tersedia")
    } else {
      plot(gap, main = "Gap Statistic")
    }
  })
  output$k_summary_table <- renderDT({
    req(results())
    kc <- results()$k_curve
    pam_kc  <- kc[kc$method == "PAM", ]
    ward_kc <- kc[kc$method == "Ward.D2", ]
    gap <- results()$gap
    gap_k <- if (!is.null(gap)) {
      tryCatch(cluster::maxSE(gap$Tab[, "gap"], gap$Tab[, "SE.sim"]), error = function(e) NA)
    } else NA
    summary_df <- data.frame(
      Kriteria = c("Silhouette (PAM) optimum", "Davies-Bouldin (PAM) optimum",
                   "Calinski-Harabasz (PAM) optimum", "Silhouette (Ward.D2) optimum",
                   "Davies-Bouldin (Ward.D2) optimum", "Calinski-Harabasz (Ward.D2) optimum",
                   "Gap statistic (maxSE)"),
      k_terpilih = c(pam_kc$k[which.max(pam_kc$Silhouette)],
                     pam_kc$k[which.min(pam_kc$DaviesBouldin)],
                     pam_kc$k[which.max(pam_kc$CalinskiHarabasz)],
                     ward_kc$k[which.max(ward_kc$Silhouette)],
                     ward_kc$k[which.min(ward_kc$DaviesBouldin)],
                     ward_kc$k[which.max(ward_kc$CalinskiHarabasz)],
                     gap_k)
    )
    datatable(summary_df, options = list(dom = "t"))
  })

  # ---------------- Tab 4: algorithm comparison ----------------
  output$algo_header <- renderText({
    req(results())
    paste0("Metrik Internal 7 Algoritma pada k = ", results()$k)
  })
  output$algo_table <- renderDT({
    req(results())
    datatable(results()$algo_metrics, options = list(dom = "t"))
  })
  output$cluster_size_plot <- renderPlot({
    req(results())
    algos <- results()$algos
    df_sizes <- do.call(rbind, lapply(names(algos), function(nm) {
      t <- table(algos[[nm]])
      data.frame(Algorithm = nm, Cluster = names(t), Size = as.numeric(t))
    }))
    ggplot(df_sizes, aes(Algorithm, Size, fill = Cluster)) +
      geom_col(position = "stack") +
      labs(title = "Ukuran Cluster per Algoritma", y = "Jumlah Wilayah") +
      theme_minimal()
  })

  # ---------------- Tab 5: ARI ----------------
  output$ari_heatmap <- renderPlot({
    req(results())
    m <- results()$ari_mat
    dfm <- reshape2::melt(m)
    ggplot(dfm, aes(Var1, Var2, fill = value)) +
      geom_tile() +
      geom_text(aes(label = round(value, 2)), size = 4) +
      scale_fill_gradient(low = "white", high = "steelblue", limits = c(0, 1)) +
      labs(title = "Adjusted Rand Index antar Algoritma", x = NULL, y = NULL, fill = "ARI") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1))
  })
  output$ari_table <- renderDT({
    req(results())
    datatable(round(results()$ari_mat, 3))
  })

  # ---------------- Tab 6: bootstrap stability ----------------
  output$jaccard_plot <- renderPlot({
    req(results())
    df <- results()$jaccard_df
    ggplot(df, aes(factor(Cluster), Jaccard, fill = Algorithm)) +
      geom_col(position = position_dodge()) +
      geom_hline(yintercept = 0.75, linetype = "dashed", color = "red") +
      labs(title = "Bootstrap Jaccard Stability per Cluster", x = "Cluster", y = "Mean Jaccard") +
      ylim(0, 1) +
      theme_minimal()
  })
  output$jaccard_table <- renderDT({
    req(results())
    datatable(results()$jaccard_df, options = list(dom = "t"))
  })
  output$sil_ci_text <- renderPrint({
    req(results())
    r <- results()
    cat("Bootstrap mean silhouette:", round(mean(r$sil_boot, na.rm = TRUE), 3), "\n")
    cat("95% percentile CI:", round(r$sil_ci[1], 3), "-", round(r$sil_ci[2], 3), "\n")
  })
  output$sil_boot_hist <- renderPlot({
    req(results())
    r <- results()
    ggplot(data.frame(sil = r$sil_boot), aes(sil)) +
      geom_histogram(bins = 30, fill = "steelblue", color = "white") +
      geom_vline(xintercept = r$sil_ci, linetype = "dashed", color = "red") +
      labs(title = "Distribusi Bootstrap Rata-rata Silhouette (solusi PAM)",
           x = "Mean Silhouette", y = "Frekuensi") +
      theme_minimal()
  })

  # ---------------- Tab 7: typology & profiles ----------------
  output$pca_plot <- renderPlot({
    req(results())
    r <- results()
    pca <- prcomp(r$Z)
    var_exp <- round(100 * (pca$sdev^2 / sum(pca$sdev^2))[1:2], 1)
    df <- data.frame(PC1 = pca$x[, 1], PC2 = pca$x[, 2],
                      Cluster = factor(r$algos$PAM), Region = rownames(r$Z))
    ggplot(df, aes(PC1, PC2, color = Cluster, label = Region)) +
      geom_point(size = 3) +
      ggrepel_or_text(df) +
      labs(title = "Proyeksi PCA (solusi PAM)",
           x = paste0("PC1 (", var_exp[1], "%)"), y = paste0("PC2 (", var_exp[2], "%)")) +
      theme_minimal()
  })

  output$profile_plot <- renderPlot({
    req(results())
    r <- results()
    Z <- r$Z; cl <- r$algos$PAM
    prof <- aggregate(Z, by = list(Cluster = cl), FUN = mean)
    prof_long <- reshape2::melt(prof, id.vars = "Cluster")
    ggplot(prof_long, aes(variable, value, fill = factor(Cluster))) +
      geom_col(position = position_dodge()) +
      labs(title = "Rata-rata Slope Terstandardisasi per Cluster",
           x = NULL, y = "Mean z-slope", fill = "Cluster") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1))
  })

  output$profile_table <- renderDT({
    req(results())
    r <- results()
    B <- r$B; cl <- r$algos$PAM
    prof <- aggregate(B, by = list(Cluster = cl), FUN = mean)
    datatable(round_df(prof), options = list(dom = "t"))
  })

  output$cluster1_members <- renderPrint({
    req(results())
    r <- results()
    cat(rownames(r$Z)[r$algos$PAM == 1], sep = "\n")
  })
  output$cluster2_members <- renderPrint({
    req(results())
    r <- results()
    other <- sort(unique(r$algos$PAM))
    other <- other[other != 1]
    for (cc in other) {
      cat("Cluster", cc, ":\n")
      cat(rownames(r$Z)[r$algos$PAM == cc], sep = "\n")
      cat("\n")
    }
  })

  # ---------------- Tab 8: sensitivity ----------------
  output$sensitivity_text <- renderPrint({
    req(results())
    r <- results()
    cat("ARI (OLS-based PAM vs Theil-Sen-based PAM):", round(r$ari_sensitivity, 3), "\n")
  })
  output$sensitivity_table <- renderDT({
    req(results())
    r <- results()
    df <- data.frame(Region = rownames(r$Z),
                      Cluster_OLS = r$algos$PAM,
                      Cluster_TheilSen = r$pam_ts)
    datatable(df, options = list(pageLength = 10))
  })
}

# ---------------- small utilities used above ----------------
round_df <- function(df) {
  num_cols <- sapply(df, is.numeric)
  df[num_cols] <- round(df[num_cols], 4)
  df
}
ggrepel_or_text <- function(df) {
  if (requireNamespace("ggrepel", quietly = TRUE)) {
    ggrepel::geom_text_repel(size = 3, max.overlaps = 20)
  } else {
    ggplot2::geom_text(size = 2.8, vjust = -0.7, check_overlap = TRUE)
  }
}

shinyApp(ui, server)
