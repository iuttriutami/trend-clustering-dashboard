# Trend-Based Clustering Dashboard — Jawa Tengah

Dashboard R Shiny pendamping paper *"A Validation Framework for Trend-Based
Clustering of Regional Development: Multi-Algorithm Agreement and Bootstrap
Stability"*. Data bawaan: panel 35 kabupaten/kota Jawa Tengah, 2020–2024
(`data/panel_data.csv`).

## Cara menjalankan

1. Install R (>= 4.1) dari https://cran.r-project.org
2. Buka `app.R` di RStudio lalu klik **Run App**, ATAU jalankan dari terminal:
   ```
   Rscript -e "shiny::runApp('.', launch.browser = TRUE)"
   ```
   dijalankan dari folder tempat `app.R` dan folder `data/` berada.
3. Saat pertama dijalankan, package yang belum ada akan otomatis diinstal
   (shiny, DT, cluster, fpc, mclust, ggplot2, reshape2). Butuh koneksi internet
   untuk instalasi pertama kali.

## Cara pakai

1. **Tab "1. Data & Setup"** — data bawaan otomatis termuat. Untuk memakai
   data lain, upload CSV dengan struktur panel (satu baris = satu
   wilayah-tahun), lalu sesuaikan pemetaan kolom wilayah/tahun, pilih
   kolom indikator, dan atur arah kebijakan (+1 = makin tinggi makin baik,
   -1 = makin tinggi makin buruk, misalnya kemiskinan & pengangguran) serta
   opsi log-transform untuk variabel skala besar (mis. PDRB, jumlah usaha).
2. Atur **k** (jumlah cluster) dan **B** (jumlah replikasi bootstrap),
   lalu klik **"Jalankan Analisis"**.
3. Jelajahi tab 2–8 untuk melihat: matriks slope, kurva pemilihan k,
   perbandingan 7 algoritma, matriks ARI, stabilitas bootstrap Jaccard,
   tipologi & profil cluster (PCA + profil rata-rata slope), dan uji
   sensitivitas estimator Theil-Sen.

## Catatan metodologis

- Slope indikator diestimasi dengan regresi OLS terhadap tahun per wilayah
  (opsi Theil-Sen tersedia di tab 8 sebagai pengecekan sensitivitas).
- Matriks slope distandardisasi (z-score) sebelum clustering.
- Davies–Bouldin dihitung manual (rumus Davies & Bouldin, 1979);
  Calinski–Harabasz dan bootstrap Jaccard memakai package `fpc`
  (`cluster.stats`, `clusterboot`) — sesuai referensi metodologi pada paper.
- Hasil telah diverifikasi menghasilkan pola yang konsisten dengan paper
  (partisi 21 vs 14, PAM–CLARA identik, ARI PAM–K-Means ≈ 0.68, Davies–Bouldin
  optimum di k = 7, Gap statistic di k = 1, Jaccard bootstrap ≈ 0.75–0.80).

## Struktur file

```
app.R                     # aplikasi Shiny (UI + server, single file)
data/panel_data.csv       # data bawaan (35 kab/kota Jateng, 2020-2024)
README.md                 # dokumen ini
```
